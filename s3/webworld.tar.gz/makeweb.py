from webworld import *

def main():
    # Parameters 
    # --------
    # Parameters for equilibriating a web
    euler_params = {}
    euler_params['del_t'] = 0.01 # Time step for Euler method
    euler_params['t_max'] = 10000 # Maximum steps of Euler method
    euler_params['eqm_tol'] = 0.01*euler_params['del_t'] # From an email from Quince, the tolerance for Euler steady state

    # Parameters for building a single web
    R = 10000
    b = 0.005
    c = 0.5
    K = 100 # Number of entries in M, made it smaller than in paper
    params = {}
    params['R'] = R
    params['b'] = b
    params['c'] = c
    params['K'] = K # Number of entries in M, made it smaller than in paper


    # Parameters for the assembly
    inv_max = 20000
    save_every = 50
    file_out = 'res1_web1.pkl'

    # Create M
    M = create_M(K) 

    # Initialise web
    web = Web() 
    web.initialise(params,M) # Now has one resource and one species, at equilibrium
    # We've now done max(web.keys()) invasions

    # Make a record of number of species
    no_mem = [1]
    for i in range(1,max(web.keys())):
        no_mem.append(1)
    no_mem.append(2)

    # Iterate for the rest
    s = 'every' + str(save_every) + 'th' + file_out
    fid2 = open(s,'wb')
    s = 'Every ' + str(save_every) + 'th web corresponding to ' + file_out
    cPickle.dump(s,fid2)
    for inv in range(max(web.keys())+1,inv_max):
        web.add_offspring(id = inv,K = K)
        web.update_S(M)
        web.update_A(c)
        web.init_F()
        web.equilibriate(euler_params,params)
        no_mem.append(len(web))
        print str(inv) + ': ' + str(len(web))
        if (mod(inv+1,save_every) == 0) and (inv != inv_max):
            cPickle.dump(web,fid2)
    fid2.close()

    fid = open(file_out, 'wb')
    cPickle.dump('Web created by makeweb.py. Pickle file contains params, euler_params, M, web, no_mem',fid)
    cPickle.dump(params,fid)
    cPickle.dump(euler_params,fid)
    cPickle.dump(M,fid)
    cPickle.dump(web,fid)
    cPickle.dump(no_mem,fid)
    fid.close()

if __name__ == "__main__":
    main()



